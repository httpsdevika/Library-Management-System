package jframe;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;
import javax.mail.Authenticator;
/**
 *
 * @author Suraj
 */
public class SendConfirmationEmail { // Class name should follow Java naming conventions (PascalCase)
   
   public boolean sendEmail(String toEmail, String subject, String body) {
        String fromEmail = "marvel511921@gmail.com"; // Replace with your email
        String password = "lntf into aqhs zuec"; // Replace with your email app password

        // Set up properties for the mail session
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        // Create a session
        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(fromEmail, password);
            }
        });

        try {
            // Create a message
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(fromEmail));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
            message.setSubject(subject);
            message.setText(body);

            // Send the message
            Transport.send(message);
            System.out.println("Email sent successfully.");
            return true; // Return true if email is sent successfully
        } catch (MessagingException e) {
            e.printStackTrace();
            return false; // Return false if there was an error sending the email
        }
    }
}
