/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jframe;

import java.sql.Connection;
import java.sql.DriverManager;
/**
 *
 * @author Suraj
 */

public class DBConnection {
    static Connection con = null;

    public static Connection getConnection() {
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Get connection to the database
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library_ms", "root", "");
        } catch (Exception e) {
            // Print the exception details
            e.printStackTrace();
        }
        return con;
    }
}